package com.example.donovantaylorinventory;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Represents the "inventory_items" table in the database.
 */
@Entity(tableName = "inventory_items")
public class InventoryItem {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String name;
    public int quantity;

    // Constructor for new items
    public InventoryItem(String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
    }
}