package com.example.donovantaylorinventory;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

/**
 * Main screen of the app. Displays the list of inventory items.
 * Handles Read, Delete, and navigation to Create/Update.
 */
public class MainActivity extends AppCompatActivity {

    private AppDatabase db;
    private InventoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Link the layout file
        setContentView(R.layout.activity_main);

        // Get database instance
        db = AppDatabase.getDatabase(getApplicationContext());

        // --- Setup RecyclerView ---
        RecyclerView recyclerView = findViewById(R.id.inventoryRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new InventoryAdapter();
        recyclerView.setAdapter(adapter);

        // --- Handle READ (Observe database) ---
        // Observe the LiveData from the DAO. When the data changes,
        // the adapter's list is automatically updated.
        db.itemDao().getAllItems().observe(this, items -> {
            adapter.submitList(items);
        });

        // --- Handle CREATE (FAB Click) ---
        FloatingActionButton fab = findViewById(R.id.addItemFab);
        fab.setOnClickListener(v -> {
            // Start AddItemActivity to create a new item
            Intent intent = new Intent(MainActivity.this, AddItemActivity.class);
            startActivity(intent);
        });

        // --- Handle UPDATE (Item Click) ---
        adapter.setOnItemClickListener(item -> {
            // Start AddItemActivity in "edit mode"
            Intent intent = new Intent(MainActivity.this, AddItemActivity.class);
            // Pass the ID of the item to be edited
            intent.putExtra("ITEM_ID", item.id);
            startActivity(intent);
        });

        // --- Handle DELETE (Delete Button Click) ---
        adapter.setOnDeleteClickListener(item -> {
            // Run delete operation on a background thread
            AppDatabase.databaseWriteExecutor.execute(() -> {
                db.itemDao().deleteItem(item);
                // Show confirmation on the main thread
                runOnUiThread(() -> {
                    Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
                });
            });
        });
    }
}