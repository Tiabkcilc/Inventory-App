package com.example.donovantaylorinventory;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Represents the "users" table in the database.
 * Each instance of this class is a row in the table.
 */
@Entity(tableName = "users")
public class User {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String username;
    public String password;

    // Constructor
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }
}