package com.example.donovantaylorinventory;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Handles user login and registration.
 */
public class LoginActivity extends AppCompatActivity {

    private AppDatabase db;
    private EditText usernameEditText;
    private EditText passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Link the layout file
        setContentView(R.layout.activity_login);

        // Get an instance of the database
        db = AppDatabase.getDatabase(getApplicationContext());

        // Get references to the UI views
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        // Set click listener for the login button
        loginButton.setOnClickListener(v -> handleLogin());

        // Set click listener for the create account button
        createAccountButton.setOnClickListener(v -> handleCreateAccount());
    }

    /**
     * Handles the login button click.
     * Validates input and checks database for user.
     */
    private void handleLogin() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Run database operations on a background thread
        AppDatabase.databaseWriteExecutor.execute(() -> {
            User user = db.userDao().findUser(username, password);

            // Run UI changes back on the main thread
            runOnUiThread(() -> {
                if (user != null) {
                    // User found, login successful
                    Toast.makeText(this, "Login Successful!", Toast.LENGTH_SHORT).show();
                    // Navigate to the MainActivity
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish(); // Close LoginActivity
                } else {
                    // User not found
                    Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    /**
     * Handles the create account button click.
     * Validates input and inserts a new user into the database.
     */
    private void handleCreateAccount() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create a new User object
        User newUser = new User(username, password);

        // Run database operations on a background thread
        AppDatabase.databaseWriteExecutor.execute(() -> {
            // Note: In a real app, you should check if the username already exists first.
            db.userDao().insertUser(newUser);

            // Show success message on the main thread
            runOnUiThread(() -> {
                Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
                // Clear fields
                usernameEditText.setText("");
                passwordEditText.setText("");
            });
        });
    }
}