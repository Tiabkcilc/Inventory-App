package com.example.donovantaylorinventory;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

/**
 * Data Access Object (DAO) for the InventoryItem table.
 */
@Dao
public interface ItemDao {
    @Insert
    void insertItem(InventoryItem item);

    @Update
    void updateItem(InventoryItem item);

    @Delete
    void deleteItem(InventoryItem item);

    @Query("SELECT * FROM inventory_items ORDER BY name ASC")
    LiveData<List<InventoryItem>> getAllItems(); // Use LiveData to observe changes

    @Query("SELECT * FROM inventory_items WHERE id = :itemId LIMIT 1")
    InventoryItem getItemById(int itemId);
}