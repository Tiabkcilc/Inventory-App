package com.example.donovantaylorinventory;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Handles both Creating a new item and Updating an existing one.
 * Also handles SMS permission request and sending.
 */
public class AddItemActivity extends AppCompatActivity {

    // Constant for SMS permission request
    private static final int SMS_PERMISSION_REQUEST_CODE = 101;

    private AppDatabase db;
    private EditText itemNameInput;
    private EditText itemQuantityInput;
    private TextView addItemHeader;

    private InventoryItem currentItem; // The item being edited (null if adding)
    private boolean isEditMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        db = AppDatabase.getDatabase(getApplicationContext());

        // Find views
        itemNameInput = findViewById(R.id.itemNameInput);
        itemQuantityInput = findViewById(R.id.itemQuantityInput);
        addItemHeader = findViewById(R.id.addItemHeader);
        Button saveButton = findViewById(R.id.saveButton);
        Button cancelButton = findViewById(R.id.cancelButton);

        // Check if we are in "Edit Mode"
        if (getIntent().hasExtra("ITEM_ID")) {
            isEditMode = true;
            addItemHeader.setText("Edit Item");
            int itemId = getIntent().getIntExtra("ITEM_ID", -1);

            // Load the item from DB on a background thread
            AppDatabase.databaseWriteExecutor.execute(() -> {
                currentItem = db.itemDao().getItemById(itemId);
                // Populate fields on the main thread
                runOnUiThread(this::populateFields);
            });
        }

        // Set save button listener
        saveButton.setOnClickListener(v -> saveItem());

        // Set cancel button listener
        cancelButton.setOnClickListener(v -> finish()); // Just close the activity
    }

    /**
     * Populates the EditText fields if in edit mode.
     */
    private void populateFields() {
        if (currentItem != null) {
            itemNameInput.setText(currentItem.name);
            itemQuantityInput.setText(String.valueOf(currentItem.quantity));
        }
    }

    /**
     * Handles saving the item (either insert or update).
     */
    private void saveItem() {
        String name = itemNameInput.getText().toString();
        String quantityStr = itemQuantityInput.getText().toString();

        if (name.isEmpty() || quantityStr.isEmpty()) {
            Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity = Integer.parseInt(quantityStr);

        AppDatabase.databaseWriteExecutor.execute(() -> {
            if (isEditMode) {
                // UPDATE existing item
                currentItem.name = name;
                currentItem.quantity = quantity;
                db.itemDao().updateItem(currentItem);
            } else {
                // CREATE new item
                InventoryItem newItem = new InventoryItem(name, quantity);
                db.itemDao().insertItem(newItem);
            }

            // After saving, check if we need to send an SMS
            if (quantity == 0) {
                // Must run permission check and UI on main thread
                runOnUiThread(() -> checkAndSendSms(name));
            }

            // Finish activity on main thread
            runOnUiThread(this::finish);
        });
    }

    // --- SMS PERMISSION AND SENDING LOGIC ---

    /**
     * Checks for SMS permission. If granted, sends SMS. If not, requests it.
     * @param itemName The name of the item that is out of stock.
     */
    private void checkAndSendSms(String itemName) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            // Permission is already granted
            sendLowStockAlert(itemName);
        } else {
            // Permission is not granted, request it
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE
            );
        }
    }

    /**
     * Sends the low stock alert via SMS.
     * @param itemName The name of the item.
     */
    private void sendLowStockAlert(String itemName) {
        // IMPORTANT: Replace "5551234" with a phone number for testing
        // You can use the emulator's built-in number (e.g., 555-521-5554)
        String phoneNumber = "5551234";
        String message = "Inventory Alert: " + itemName + " is now out of stock.";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Low stock SMS alert sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS failed to send. Check permissions.", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    /**
     * Callback for after the user responds to the permission request.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // User GRANTED permission
                Toast.makeText(this, "SMS permission granted. Alerts are active.", Toast.LENGTH_SHORT).show();
                // You could re-trigger the send here if needed, but for now
                // we'll just notify the user. The next time an item hits 0, it will send.
            } else {
                // User DENIED permission
                // The app MUST continue to function.
                Toast.makeText(this, "SMS permission denied. Low stock alerts will be disabled.", Toast.LENGTH_LONG).show();
            }
        }
    }
}