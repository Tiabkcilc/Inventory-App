package com.example.donovantaylorinventory;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

/**
 * Adapter for the RecyclerView in MainActivity.
 * Handles displaying the list of inventory items.
 */
public class InventoryAdapter extends ListAdapter<InventoryItem, InventoryAdapter.ItemViewHolder> {

    private OnItemClickListener listener;
    private OnDeleteClickListener deleteListener;

    public InventoryAdapter() {
        super(DIFF_CALLBACK);
    }

    // DiffUtil calculates the difference between two lists to optimize updates
    private static final DiffUtil.ItemCallback<InventoryItem> DIFF_CALLBACK = new DiffUtil.ItemCallback<InventoryItem>() {
        @Override
        public boolean areItemsTheSame(@NonNull InventoryItem oldItem, @NonNull InventoryItem newItem) {
            return oldItem.id == newItem.id;
        }

        @Override
        public boolean areContentsTheSame(@NonNull InventoryItem oldItem, @NonNull InventoryItem newItem) {
            return oldItem.name.equals(newItem.name) && oldItem.quantity == newItem.quantity;
        }
    };

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the item_row.xml layout for each row
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_row, parent, false);
        return new ItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        // Get the item at the current position
        InventoryItem currentItem = getItem(position);

        // Bind the item's data to the views in the ViewHolder
        holder.itemNameTextView.setText(currentItem.name);
        holder.itemQuantityTextView.setText("Quantity: " + currentItem.quantity);
    }

    // ViewHolder class to hold the views for each row
    class ItemViewHolder extends RecyclerView.ViewHolder {
        private final TextView itemNameTextView;
        private final TextView itemQuantityTextView;
        private final ImageButton deleteItemButton;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            itemNameTextView = itemView.findViewById(R.id.itemNameTextView);
            itemQuantityTextView = itemView.findViewById(R.id.itemQuantityTextView);
            deleteItemButton = itemView.findViewById(R.id.deleteItemButton);

            // Set click listener for the entire row (for editing)
            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION) {
                    listener.onItemClick(getItem(position));
                }
            });

            // Set click listener for the delete button
            deleteItemButton.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (deleteListener != null && position != RecyclerView.NO_POSITION) {
                    deleteListener.onDeleteClick(getItem(position));
                }
            });
        }
    }

    // Interface for handling item clicks (to edit)
    public interface OnItemClickListener {
        void onItemClick(InventoryItem item);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    // Interface for handling delete clicks
    public interface OnDeleteClickListener {
        void onDeleteClick(InventoryItem item);
    }

    public void setOnDeleteClickListener(OnDeleteClickListener listener) {
        this.deleteListener = listener;
    }
}